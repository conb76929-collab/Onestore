$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dist = Join-Path $root "dist"
$packageDir = Join-Path $root "package"
$sedPath = Join-Path $root "xmo.sed"
$htaPath = Join-Path $root "Xmo.hta"
$cmdPath = Join-Path $packageDir "launch-xmo.cmd"
$targetExe = Join-Path $dist "Xmo.exe"

if (-not (Test-Path $htaPath)) {
    throw "Missing Xmo.hta in $root"
}

New-Item -ItemType Directory -Force -Path $dist | Out-Null
New-Item -ItemType Directory -Force -Path $packageDir | Out-Null

$cmdContent = @"
@echo off
setlocal
mshta.exe "%~dp0Xmo.hta"
"@
Set-Content -LiteralPath $cmdPath -Value $cmdContent -Encoding ASCII

$sedContent = @"
[Version]
Class=IEXPRESS
SEDVersion=3
[Options]
PackagePurpose=InstallApp
ShowInstallProgramWindow=0
HideExtractAnimation=1
UseLongFileName=1
InsideCompressed=0
CAB_FixedSize=0
CAB_ResvCodeSigning=0
RebootMode=N
InstallPrompt=
DisplayLicense=
FinishMessage=
TargetName=$targetExe
FriendlyName=Xmo
AppLaunched=launch-xmo.cmd
PostInstallCmd=<None>
AdminQuietInstCmd=
UserQuietInstCmd=
SourceFiles=SourceFiles
[SourceFiles]
SourceFiles0=$packageDir\
[SourceFiles0]
%FILE0%=Xmo.hta
%FILE1%=launch-xmo.cmd
[Strings]
FILE0=Xmo.hta
FILE1=launch-xmo.cmd
"@

Set-Content -LiteralPath $sedPath -Value $sedContent -Encoding ASCII
Copy-Item -LiteralPath $htaPath -Destination (Join-Path $packageDir "Xmo.hta") -Force

Write-Host "Building Xmo.exe..."
& iexpress.exe /N $sedPath | Out-Null

if (-not (Test-Path $targetExe)) {
    throw "Build failed. Expected $targetExe"
}

Write-Host "Created $targetExe"
