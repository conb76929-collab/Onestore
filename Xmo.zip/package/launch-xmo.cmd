@echo off
setlocal
mshta.exe "%~dp0Xmo.hta"
