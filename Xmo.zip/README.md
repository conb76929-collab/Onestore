# Xmo

Xmo is a Windows desktop antivirus-style prototype with a full menu-driven interface.

## Files

- `Xmo.hta` - the desktop UI
- `build-xmo.ps1` - packages the app into `dist/Xmo.exe` using Windows `IExpress`

## Build

Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\build-xmo.ps1
```

The packaged executable will be created at `dist\Xmo.exe`.

## Notes

This is a UI/demo build. The scan engine, quarantine, and tools are simulated for local prototype use and do not provide real antivirus detection.
